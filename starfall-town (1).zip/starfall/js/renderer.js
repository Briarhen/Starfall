// ═══════════════════════════════════════════════════════
//  RENDERER
// ═══════════════════════════════════════════════════════

const R = {};

R.init = (canvas) => {
  R.canvas = canvas;
  R.ctx = canvas.getContext('2d');
  R.ctx.imageSmoothingEnabled = false;
  R.mmCtx = document.getElementById('mm').getContext('2d');
  R.mmCtx.imageSmoothingEnabled = false;
};

// ── TILE DETAIL RENDERER ─────────────────────────────
R.drawTile = (ctx, tx, ty, px, py, tick) => {
  const T = C.T;
  const s = C.TS; // tile size in screen pixels
  const tile = TM.get(tx, ty);
  const col = TILE_COL[tile] || '#5aaa2a';

  ctx.fillStyle = col;
  ctx.fillRect(px, py, s, s);

  switch(tile) {
    case T.GRASS: {
      // Subtle grass detail — slight variation, occasional blade
      const seed = (tx * 7 + ty * 13) % 17;
      if(seed < 4) { ctx.fillStyle='rgba(0,0,0,0.07)'; ctx.fillRect(px+seed*5+2, py+seed*3+4, 3, 2); }
      if(seed === 2) { ctx.fillStyle='rgba(255,255,255,0.06)'; ctx.fillRect(px+8, py+3, 4, 1); }
      // Grass blade
      if(seed < 2) { ctx.fillStyle='#6ac030'; ctx.fillRect(px+5, py+2, 2, 5); ctx.fillRect(px+14, py+5, 2, 4); }
      break;
    }
    case T.DARK_GRASS: {
      ctx.fillStyle = '#408020';
      ctx.fillRect(px+2,py+3,3,6); ctx.fillRect(px+10,py+1,3,7); ctx.fillRect(px+17,py+5,2,5);
      ctx.fillStyle = '#308018';
      ctx.fillRect(px+3,py+2,1,4); ctx.fillRect(px+11,py+0,1,5);
      break;
    }
    case T.PATH: {
      // Warm dirt with tyre/foot marks
      ctx.fillStyle = 'rgba(0,0,0,0.1)';
      ctx.fillRect(px, py, s, 1); ctx.fillRect(px, py, 1, s);
      ctx.fillStyle = 'rgba(255,255,255,0.07)';
      ctx.fillRect(px+1, py+1, s-2, 1);
      const seed2 = (tx*5+ty*11)%9;
      if(seed2 < 2){ ctx.fillStyle='rgba(0,0,0,0.06)'; ctx.fillRect(px+seed2*8+2, py+4, 5, 2); }
      break;
    }
    case T.COBBLE: {
      // Stone cobble pattern
      const row = ty % 2;
      const off = row * 12;
      ctx.fillStyle = '#8a7868';
      ctx.fillRect(px+(off)%s, py+1, 10, 10);
      ctx.fillRect(px+(off+12)%s, py+1, 10, 10);
      ctx.fillStyle = 'rgba(255,255,255,0.08)';
      ctx.fillRect(px+(off)%s+1, py+2, 8, 1);
      ctx.fillRect(px+(off+12)%s+1, py+2, 8, 1);
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(px+(off)%s, py+11, 10, 1);
      break;
    }
    case T.GRAVEL: {
      ctx.fillStyle = '#a09888';
      for(let i=0;i<3;i++){ const gx=(tx*13+ty*7+i*5)%20; const gy=(tx*7+ty*11+i*3)%20;
        ctx.fillRect(px+gx, py+gy, 2, 2); }
      break;
    }
    case T.WATER: {
      const wave = tick * 0.04 + tx * 0.5 + ty * 0.3;
      ctx.fillStyle = `rgba(60,140,220,${0.3+0.1*Math.sin(wave)})`;
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = `rgba(180,220,255,0.2)`;
      ctx.fillRect(px+2+Math.floor(Math.sin(wave)*2), py+4, 10, 2);
      ctx.fillRect(px+14+Math.floor(Math.cos(wave)*2), py+14, 7, 2);
      // foam
      ctx.fillStyle = `rgba(220,240,255,0.1)`;
      ctx.fillRect(px, py, s, 2);
      break;
    }
    case T.SHALLOW: {
      const w2 = tick * 0.03 + tx * 0.4;
      ctx.fillStyle = `rgba(80,170,230,0.4)`;
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = `rgba(200,235,255,0.25)`;
      ctx.fillRect(px+Math.floor(Math.sin(w2)*3)+3, py+6, 8, 2);
      break;
    }
    case T.DEEP_WATER: {
      ctx.fillStyle = 'rgba(20,60,160,0.5)';
      ctx.fillRect(px, py, s, s);
      break;
    }
    case T.TREE:
    case T.TREE2: {
      // Trunk
      ctx.fillStyle = '#5c3a18';
      ctx.fillRect(px+8, py+14, 8, 10);
      ctx.fillStyle = '#7a5020';
      ctx.fillRect(px+9, py+15, 3, 8);
      // Canopy — multi-layer for depth
      const leafDark = tile===T.TREE ? '#246820' : '#1c6020';
      const leafMid  = tile===T.TREE ? '#2e8828' : '#267030';
      const leafBright = tile===T.TREE ? '#38a030' : '#308040';
      ctx.fillStyle = leafDark;
      ctx.fillRect(px+2, py+2, 20, 14);
      ctx.fillStyle = leafMid;
      ctx.fillRect(px+4, py+0, 16, 12);
      ctx.fillRect(px+2, py+6, 20, 6);
      ctx.fillStyle = leafBright;
      ctx.fillRect(px+6, py+0, 12, 8);
      ctx.fillRect(px+4, py+4, 16, 5);
      // Highlight
      ctx.fillStyle = 'rgba(255,255,255,0.08)';
      ctx.fillRect(px+8, py+1, 6, 3);
      break;
    }
    case T.BUSH: {
      ctx.fillStyle = '#257820';
      ctx.fillRect(px+2, py+8, 20, 10);
      ctx.fillStyle = '#309828';
      ctx.fillRect(px+4, py+4, 16, 12);
      ctx.fillStyle = '#3ab830';
      ctx.fillRect(px+6, py+4, 12, 8);
      ctx.fillStyle = 'rgba(255,255,255,0.1)';
      ctx.fillRect(px+8, py+5, 6, 3);
      // Berries
      if((tx+ty)%3===0){ ctx.fillStyle='#e83030'; ctx.fillRect(px+6,py+8,3,3); ctx.fillRect(px+14,py+9,3,3); }
      break;
    }
    case T.TALL_GRASS: {
      ctx.fillStyle = '#4a9820';
      ctx.fillRect(px+2, py+6, 3, 14); ctx.fillRect(px+8, py+3, 3, 17); ctx.fillRect(px+15, py+7, 3, 13);
      ctx.fillStyle = '#5cb828';
      ctx.fillRect(px+3, py+5, 2, 8); ctx.fillRect(px+10, py+2, 2, 9);
      // sway suggestion
      if((tick+tx+ty)%60 < 30){ ctx.fillStyle='rgba(100,200,40,0.15)'; ctx.fillRect(px,py,s,s); }
      break;
    }
    case T.FLOWER: {
      ctx.fillStyle = '#50a018';
      ctx.fillRect(px+8, py+12, 4, 8); ctx.fillRect(px+16, py+10, 3, 10);
      // petals
      const fcolor = (tx+ty)%3===0 ? '#f870a8' : (tx+ty)%3===1 ? '#f8e020' : '#a870f8';
      ctx.fillStyle = fcolor;
      ctx.fillRect(px+5, py+6, 8, 8); ctx.fillRect(px+6, py+5, 6, 10);
      ctx.fillStyle = fcolor;
      ctx.fillRect(px+15, py+4, 7, 7);
      ctx.fillStyle = '#fff080';
      ctx.fillRect(px+8, py+8, 3, 3); ctx.fillRect(px+17, py+6, 2, 2);
      break;
    }
    case T.CROP: {
      ctx.fillStyle = '#50920c';
      ctx.fillRect(px+2, py+4, 5, 16); ctx.fillRect(px+13, py+4, 5, 16);
      ctx.fillStyle = '#70c020';
      ctx.fillRect(px+3, py+2, 3, 8); ctx.fillRect(px+14, py+2, 3, 8);
      ctx.fillStyle = '#88d838';
      ctx.fillRect(px+4, py+1, 1, 4); ctx.fillRect(px+15, py+1, 1, 4);
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.fillRect(px+4, py+4, 2, 4); ctx.fillRect(px+15, py+4, 2, 4);
      break;
    }
    case T.FENCE: {
      ctx.fillStyle = '#7a5828';
      ctx.fillRect(px, py+8, s, 4);
      ctx.fillRect(px+4, py, 4, s);
      ctx.fillRect(px+16, py, 4, s);
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(px+4, py, 1, s);
      break;
    }
    case T.WALL: {
      // Building wall — stone/brick
      ctx.fillStyle = '#706058';
      ctx.fillRect(px, py, s, s);
      // Brick pattern
      const brow = ty%2;
      const boff = brow * 12;
      ctx.fillStyle = '#80706a';
      ctx.fillRect(px+(boff%s), py+2, 10, 8);
      ctx.fillRect(px+(boff+12)%s, py+2, 10, 8);
      ctx.fillRect(px+(boff+6)%s, py+12, 10, 8);
      ctx.fillStyle = '#605048';
      ctx.fillRect(px, py, s, 2);
      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.fillRect(px+(boff%s)+1, py+3, 8, 1);
      break;
    }
    case T.BUILDING_FLOOR: {
      // Wooden floor planks
      const plank = (ty%2===0) ? '#c8b888' : '#d0c090';
      ctx.fillStyle = plank;
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = 'rgba(0,0,0,0.08)';
      ctx.fillRect(px, py, s, 1);
      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.fillRect(px+1, py+1, s-2, 1);
      break;
    }
    case T.DOOR: {
      ctx.fillStyle = '#6848a0';
      ctx.fillRect(px+2, py, 20, s);
      // Door frame
      ctx.fillStyle = '#8868c0';
      ctx.fillRect(px+2, py, 2, s);
      ctx.fillRect(px+20, py, 2, s);
      ctx.fillRect(px+2, py, 20, 3);
      // Door handle
      ctx.fillStyle = '#f8d820';
      ctx.fillRect(px+16, py+10, 3, 3);
      // Door panels
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(px+5, py+4, 7, 8);
      ctx.fillRect(px+14, py+4, 7, 8);
      break;
    }
    case T.SIGN: {
      ctx.fillStyle = '#c09060';
      ctx.fillRect(px+4, py+4, 16, 12);
      ctx.fillStyle = '#987040';
      ctx.fillRect(px+11, py+16, 3, 6);
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.fillRect(px+5, py+5, 14, 1);
      // text lines
      ctx.fillStyle = '#503018';
      ctx.fillRect(px+6, py+7, 12, 2); ctx.fillRect(px+6, py+11, 10, 2);
      break;
    }
    case T.PLANTER: {
      ctx.fillStyle = '#6c4830';
      ctx.fillRect(px+2, py+8, 20, 12);
      ctx.fillStyle = '#503820';
      ctx.fillRect(px+2, py+8, 20, 2);
      ctx.fillStyle = '#409020';
      ctx.fillRect(px+4, py+2, 16, 8);
      ctx.fillStyle = '#50b028';
      ctx.fillRect(px+6, py+0, 12, 6);
      ctx.fillStyle = '#e85898';
      ctx.fillRect(px+8, py+1, 4, 4);
      break;
    }
    case T.ROCK: {
      ctx.fillStyle = '#808080';
      ctx.fillRect(px+2, py+6, 20, 14);
      ctx.fillRect(px+6, py+2, 12, 18);
      ctx.fillStyle = '#a0a0a0';
      ctx.fillRect(px+4, py+4, 10, 8);
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.fillRect(px+6, py+5, 5, 3);
      ctx.fillStyle = '#606060';
      ctx.fillRect(px+14, py+14, 6, 4);
      break;
    }
    case T.LOG: {
      ctx.fillStyle = '#8a6030';
      ctx.fillRect(px, py+6, s, 12);
      ctx.fillStyle = '#a07840';
      ctx.fillRect(px+1, py+8, s-2, 7);
      ctx.fillStyle = '#c09050';
      ctx.fillRect(px+0, py+6, 5, 12); ctx.fillRect(px+19, py+6, 5, 12);
      ctx.fillStyle = '#7a5020';
      ctx.fillRect(px+1, py+9, 3, 2); ctx.fillRect(px+20, py+9, 3, 2);
      break;
    }
    case T.DOCK: {
      ctx.fillStyle = '#a08040';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = '#c0a050';
      ctx.fillRect(px+1, py+1, s-2, 4);
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      ctx.fillRect(px, py+8, s, 2); ctx.fillRect(px, py+18, s, 2);
      break;
    }
    case T.BRIDGE: {
      ctx.fillStyle = '#b89050';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = '#d0b060';
      ctx.fillRect(px, py+2, s, 4); ctx.fillRect(px, py+14, s, 4);
      ctx.fillStyle = 'rgba(0,0,0,0.1)';
      ctx.fillRect(px, py+6, s, 2); ctx.fillRect(px, py+18, s, 2);
      break;
    }
    case T.SAND: {
      ctx.fillStyle = '#e8d880';
      const seed3 = (tx*11+ty*7)%15;
      if(seed3 < 3){ ctx.fillStyle='rgba(0,0,0,0.08)'; ctx.fillRect(px+seed3*6,py+seed3*4,4,3); }
      break;
    }
    case T.CLIFF: {
      ctx.fillStyle = '#504030';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = '#605048';
      ctx.fillRect(px, py, s, s/3);
      ctx.fillStyle = 'rgba(0,0,0,0.2)';
      ctx.fillRect(px, py+s-4, s, 4);
      break;
    }
    case T.CLIFF: break;
  }
};

// ── MAIN RENDER ──────────────────────────────────────
R.render = (G) => {
  const ctx = R.ctx;
  const T = C.TS;
  const cam = G.camera;

  ctx.clearRect(0, 0, C.VW, C.VH);

  // Sky fill (shown if camera near map edges)
  ctx.fillStyle = '#3a6898';
  ctx.fillRect(0, 0, C.VW, C.VH);

  // ── TILES ──
  const startTX = Math.max(0, Math.floor(cam.x / T));
  const endTX   = Math.min(C.MAP_W, startTX + Math.ceil(C.VW / T) + 2);
  const startTY = Math.max(0, Math.floor(cam.y / T));
  const endTY   = Math.min(C.MAP_H, startTY + Math.ceil(C.VH / T) + 2);

  for(let ty = startTY; ty < endTY; ty++) {
    for(let tx = startTX; tx < endTX; tx++) {
      const px = Math.floor(tx * T - cam.x);
      const py = Math.floor(ty * T - cam.y);
      R.drawTile(ctx, tx, ty, px, py, G.tick);
    }
  }

  // ── DEPTH-SORTED ENTITIES (player + NPCs) ──
  const entities = [
    { y: G.player.y, draw: () => R.drawPlayer(ctx, G, cam) },
    ...G.npcs.map(n => ({ y: n.y, draw: () => R.drawNPCEntity(ctx, n, cam, G) }))
  ];
  entities.sort((a,b) => a.y - b.y);
  entities.forEach(e => e.draw());

  // ── BUILDING DOOR LABELS ──
  TM.buildingDoors.forEach(d => {
    const sx = d.x * T - cam.x + T/2;
    const sy = d.y * T - cam.y - 8;
    if(sx < -20 || sx > C.VW+20 || sy < -20 || sy > C.VH+20) return;
    const distToPlayer = Math.hypot((d.x*T+T/2)-G.player.x, (d.y*T+T/2)-G.player.y);
    if(distToPlayer < 60) {
      ctx.fillStyle = 'rgba(4,2,14,0.85)';
      const tw = ctx.measureText(d.label).width + 10;
      ctx.font = '9px monospace';
      ctx.fillRect(sx - tw/2 - 2, sy - 12, tw + 4, 13);
      ctx.fillStyle = '#c4a0ff';
      ctx.textAlign = 'center';
      ctx.fillText(d.label, sx, sy - 1);
      ctx.textAlign = 'left';
      // Enter hint
      if(distToPlayer < 36) {
        ctx.fillStyle = 'rgba(4,2,14,0.85)';
        ctx.fillRect(sx-22, sy-26, 44, 12);
        ctx.fillStyle = '#9a70df';
        ctx.textAlign='center';
        ctx.font='8px monospace';
        ctx.fillText('[E] Enter', sx, sy-16);
        ctx.textAlign='left';
      }
    }
  });

  // ── DAY/NIGHT OVERLAY ──
  R.drawNightOverlay(ctx, G.world.gmin);

  // ── CRASH SITE GLOW ──
  const crashX = 91 * T - cam.x;
  const crashY = 26 * T - cam.y;
  const crashDist = Math.hypot(G.player.x - 91*T, G.player.y - 26*T);
  if(crashDist < 200) {
    const ga = 0.15 * (1 - crashDist/200);
    ctx.fillStyle = `rgba(255,100,30,${ga})`;
    ctx.fillRect(0,0,C.VW,C.VH);
  }
};

R.drawPlayer = (ctx, G, cam) => {
  const sx = Math.floor(G.player.x - cam.x) - 12; // 24px sprite, center
  const sy = Math.floor(G.player.y - cam.y) - 28;
  drawCharacter(ctx, sx, sy, G.player, G.player.dir, G.player.frame, 2);
  // Name tag
  R.drawNameTag(ctx, sx + 12, sy, G.player.name, '#c4a0ff');
};

R.drawNPCEntity = (ctx, n, cam, G) => {
  const sx = Math.floor(n.x - cam.x) - 12;
  const sy = Math.floor(n.y - cam.y) - 28;
  if(sx < -60 || sx > C.VW+20 || sy < -80 || sy > C.VH+20) return;

  drawCharacter(ctx, sx, sy, n, n.dir, n.frame, 2);

  const dist = Math.hypot(n.x - G.player.x, n.y - G.player.y);
  const nameCol = n.romanceable ? '#f8b0ff' : '#9a70df';
  R.drawNameTag(ctx, sx+12, sy, n.name, nameCol);

  if(dist < C.INTERACT_RANGE) {
    ctx.font = '8px monospace';
    ctx.fillStyle = 'rgba(4,2,14,0.85)';
    ctx.textAlign = 'center';
    const label = '[E] Talk';
    const lw = ctx.measureText(label).width + 8;
    ctx.fillRect(sx+12-lw/2, sy-26, lw, 12);
    ctx.fillStyle = '#c4a0ff';
    ctx.fillText(label, sx+12, sy-16);
    ctx.textAlign = 'left';
  }
};

R.drawNameTag = (ctx, cx, cy, name, col) => {
  ctx.font = '9px monospace';
  const tw = ctx.measureText(name).width;
  ctx.fillStyle = 'rgba(4,2,14,0.82)';
  ctx.fillRect(cx - tw/2 - 4, cy - 14, tw + 8, 12);
  ctx.fillStyle = col;
  ctx.textAlign = 'center';
  ctx.fillText(name, cx, cy - 4);
  ctx.textAlign = 'left';
};

R.drawNightOverlay = (ctx, gmin) => {
  const hour = gmin / 60;
  let alpha = 0;
  if(hour < 5) alpha = 0.78;
  else if(hour < 7) alpha = 0.78 * (1 - (hour-5)/2);
  else if(hour < 18) alpha = 0;
  else if(hour < 20) alpha = (hour-18)/2 * 0.55;
  else alpha = 0.55 + Math.min(0.23, (hour-20)*0.1);

  if(alpha > 0) {
    ctx.fillStyle = `rgba(8,4,30,${alpha})`;
    ctx.fillRect(0, 0, C.VW, C.VH);
    // Stars at night
    if(alpha > 0.3) {
      ctx.fillStyle = `rgba(220,200,255,${(alpha-0.3)*0.6})`;
      for(let i=0;i<60;i++){
        const sx=(i*197.3)%C.VW, sy=(i*93.7)%120;
        ctx.fillRect(sx,sy,i%3===0?2:1,1);
      }
    }
  }
};

// ── MINIMAP ───────────────────────────────────────────
R.renderMinimap = (G) => {
  const ctx = R.mmCtx;
  const W = 100, H = 100;
  const scX = W / C.MAP_W, scY = H / C.MAP_H;
  ctx.fillStyle = '#04020e';
  ctx.fillRect(0, 0, W, H);

  const MM_COL = {
    [C.T.GRASS]:'#3a7a20', [C.T.DARK_GRASS]:'#2a6018',
    [C.T.PATH]:'#8a7040', [C.T.COBBLE]:'#706050', [C.T.GRAVEL]:'#7a6858',
    [C.T.WATER]:'#1840a8', [C.T.SHALLOW]:'#3068c0', [C.T.DEEP_WATER]:'#0c2880',
    [C.T.TREE]:'#184010', [C.T.TREE2]:'#185018', [C.T.BUSH]:'#206018',
    [C.T.TALL_GRASS]:'#2a6820', [C.T.FLOWER]:'#a04070',
    [C.T.WALL]:'#504038', [C.T.BUILDING_FLOOR]:'#786850', [C.T.DOOR]:'#604890',
    [C.T.CROP]:'#407010', [C.T.FENCE]:'#604828',
    [C.T.DOCK]:'#6a5030', [C.T.BRIDGE]:'#806040',
    [C.T.SAND]:'#a09050', [C.T.CLIFF]:'#382818',
    [C.T.ROCK]:'#585858', [C.T.LOG]:'#604020',
    [C.T.SIGN]:'#806040', [C.T.PLANTER]:'#404020',
  };

  for(let ty=0; ty<C.MAP_H; ty+=2) {
    for(let tx=0; tx<C.MAP_W; tx+=2) {
      ctx.fillStyle = MM_COL[TM.get(tx,ty)] || '#3a7a20';
      ctx.fillRect(tx*scX, ty*scY, scX*2+0.5, scY*2+0.5);
    }
  }

  // NPCs as dots
  ctx.fillStyle = '#9a70df';
  G.npcs.forEach(n => {
    const mx = (n.x/C.TS)*scX, my = (n.y/C.TS)*scY;
    ctx.fillRect(mx-1,my-1,2.5,2.5);
  });

  // Player
  const px = (G.player.x/C.TS)*scX, py = (G.player.y/C.TS)*scY;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(px-2, py-2, 4, 4);

  // Viewport rect
  const vx = (G.camera.x/C.TS)*scX, vy = (G.camera.y/C.TS)*scY;
  const vw = (C.VW/C.TS)*scX, vh = (C.VH/C.TS)*scY;
  ctx.strokeStyle = 'rgba(196,160,255,0.4)';
  ctx.lineWidth = 0.5;
  ctx.strokeRect(vx, vy, vw, vh);
};
