// ═══════════════════════════════════════════════════════
//  NPCs  —  22 citizens of Fernhaven
//  6 Romanceable: 3 female, 3 male (marked romanceable:true)
// ═══════════════════════════════════════════════════════

const NPCS = {};

// Schedule entry: { startMin, x, y, dir, idle }
// NPC wanders near their scheduled position

NPCS.defs = [

  // ══════════════════════════
  //  ROMANCEABLE — FEMALE (3)
  // ══════════════════════════

  {
    id:'maren', name:'Dr. Maren', romanceable:true, gender:'F',
    role:'Doctor & town physician',
    desc:'Calm, precise, quietly warm. Has a dry wit that surprises people.',
    skin:2, hairStyle:9, hairColor:14, eyeColor:0, feature:6, earFeather:0,
    suitColor:4, suitTrim:2,
    heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:360, x:41, y:27, dir:2},   // 6am: clinic
      {startMin:480, x:50, y:41, dir:2},   // 8am: town square coffee
      {startMin:600, x:41, y:27, dir:2},   // 10am: clinic
      {startMin:1080, x:50, y:41, dir:2},  // 6pm: town square walk
      {startMin:1200, x:41, y:27, dir:0},  // 8pm: clinic/home
    ],
    dialogue:[
      "Somehow you're completely uninjured. Your biology is fascinating.",
      "I keep notes on every patient. Yours is... the most interesting file I've ever opened.",
      "How are you settling in? The first few weeks are the hardest.",
      "I grew up here. Sometimes I wonder what's beyond the forest. Now you've come from it.",
      "Get some sleep. Even aliens need rest. I assume.",
    ],
  },

  {
    id:'pip', name:'Pip', romanceable:true, gender:'F',
    role:'Enthusiastic explorer, town gossip (kind-hearted)',
    desc:'Bubbly, curious, talks fast. Secretly brave — first to enter the deep forest.',
    skin:1, hairStyle:10, hairColor:10, eyeColor:4, feature:1, earFeather:2,
    suitColor:3, suitTrim:7,
    heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:360, x:50, y:41, dir:2},   // 6am: plaza
      {startMin:480, x:30, y:36, dir:3},   // 8am: rancher area
      {startMin:720, x:52, y:27, dir:2},   // noon: main road
      {startMin:900, x:55, y:83, dir:2},   // 3pm: south meadow
      {startMin:1140, x:22, y:47, dir:0},  // 7pm: home (Pip's house)
    ],
    dialogue:[
      "You're really here! I heard the crash from my bedroom — sounded like the whole sky fell!",
      "I've collected seventeen different feathers from the forest. Want to see? Actually, later.",
      "Is space scary? I imagine it's like being inside a very dark, very quiet jar.",
      "I found a trail past the old oak that nobody else knows about. Maybe I'll show you.",
      "I'm not nosy, I'm just... deeply interested in everyone's business. There's a difference.",
    ],
  },

  {
    id:'vex', name:'Tailor Vex', romanceable:true, gender:'F',
    role:'Master tailor, perfectionist, quietly dramatic',
    desc:'Elegant and cutting. Speaks in observations that cut like scissors. Actually very loyal.',
    skin:9, hairStyle:11, hairColor:12, eyeColor:8, feature:0, earFeather:3,
    suitColor:7, suitTrim:5,
    heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:420, x:62, y:27, dir:2},   // 7am: shop
      {startMin:720, x:50, y:41, dir:1},   // noon: plaza
      {startMin:900, x:62, y:27, dir:2},   // 3pm: shop
      {startMin:1140, x:55, y:83, dir:2},  // 7pm: meadow walk
      {startMin:1260, x:62, y:27, dir:0},  // 9pm: home/shop
    ],
    dialogue:[
      "That suit is sleek. Functional. I could make it extraordinary. Come by the shop.",
      "I designed the Mayor's festival coat. He cried. It was my finest hour.",
      "You have an unusual silhouette. I mean that as a compliment. Obviously.",
      "I've been working on something for deep-forest travel. I need rarer materials though.",
      "Most people here wouldn't know good craftsmanship if it stitched itself onto them.",
    ],
  },

  // ══════════════════════════
  //  ROMANCEABLE — MALE (3)
  // ══════════════════════════

  {
    id:'rael', name:'Rael', romanceable:true, gender:'M',
    role:'Fisherman, quiet philosopher, early riser',
    desc:'Tall, reserved, beautiful in a way he\'s completely unaware of. Speaks slowly and means it.',
    skin:5, hairStyle:6, hairColor:15, eyeColor:6, feature:5, earFeather:1,
    suitColor:1, suitTrim:2,
    heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:300, x:88, y:91, dir:2},   // 5am: dock fishing
      {startMin:600, x:57, y:36, dir:0},   // 10am: cottage
      {startMin:720, x:50, y:41, dir:2},   // noon: plaza
      {startMin:900, x:88, y:91, dir:2},   // 3pm: dock again
      {startMin:1200, x:57, y:36, dir:0},  // 8pm: home
    ],
    dialogue:[
      "Quiet here. The fish don't ask questions. I appreciate that.",
      "Come fish with me sometime. Before sunrise. The water's still like glass then.",
      "I heard what happened. That must have been terrifying. You don't have to talk about it.",
      "I come out here when things get too loud inside my own head.",
      "The river runs north into the deep forest. I've followed it. Once.",
    ],
  },

  {
    id:'sol', name:'Sol', romanceable:true, gender:'M',
    role:'Wandering artist, gallery owner, quietly intense',
    desc:'Observant, expressive, messy in a charming way. Collects beautiful things including people.',
    skin:2, hairStyle:7, hairColor:6, eyeColor:9, feature:2, earFeather:0,
    suitColor:6, suitTrim:4,
    heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:480, x:61, y:47, dir:2},   // 8am: gallery
      {startMin:720, x:55, y:75, dir:2},   // noon: south meadow (sketching)
      {startMin:960, x:61, y:47, dir:2},   // 4pm: gallery
      {startMin:1140, x:50, y:41, dir:1},  // 7pm: plaza
      {startMin:1260, x:61, y:47, dir:0},  // 9pm: home/gallery
    ],
    dialogue:[
      "Fernhaven gets quiet in the evenings. I like to walk. Want to join sometime?",
      "I've been trying to paint the crash site. Nothing captures the colour of reentry.",
      "You're interesting. Most people here are interesting too, but differently.",
      "I collect things from the forest. Rocks, feathers, strange fungi. Come see.",
      "Don't stay out past two. You'll wake up somewhere embarrassing. Learned that myself.",
    ],
  },

  {
    id:'caspian', name:'Caspian', romanceable:true, gender:'M',
    role:'Blacksmith\'s apprentice, strong opinions, secretly tender',
    desc:'Loud, opinionated, quick to laugh at himself. Works hard and doesn\'t hide it.',
    skin:7, hairStyle:0, hairColor:2, eyeColor:3, feature:4, earFeather:0,
    suitColor:7, suitTrim:3,
    heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:420, x:36, y:47, dir:2},   // 7am: blacksmith
      {startMin:720, x:50, y:41, dir:2},   // noon: plaza (eating)
      {startMin:840, x:36, y:47, dir:2},   // 2pm: blacksmith
      {startMin:1080, x:55, y:80, dir:2},  // 6pm: pond area
      {startMin:1200, x:36, y:47, dir:0},  // 8pm: home
    ],
    dialogue:[
      "Oh, you're the one who fell from the sky. Bold entrance.",
      "I can sharpen your tools, fix your equipment, reinforce just about anything. Good to know, yeah?",
      "People say I'm too loud. I say they're not loud enough.",
      "Master Doran says I'll take over the smithy in five years. I'm planning three.",
      "I come to the pond to think. Don't tell anyone. Ruins the image.",
    ],
  },

  // ══════════════════════════
  //  NON-ROMANCEABLE CITIZENS
  // ══════════════════════════

  {
    id:'brix', name:'Farmer Brix', romanceable:false, gender:'M',
    role:'Head farmer, kind, endlessly patient',
    skin:8, hairStyle:1, hairColor:5, eyeColor:3, feature:3, earFeather:0,
    suitColor:5, suitTrim:3, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:300, x:10, y:61, dir:2},
      {startMin:600, x:22, y:47, dir:0},
      {startMin:900, x:10, y:61, dir:2},
      {startMin:1140, x:50, y:41, dir:2},
    ],
    dialogue:[
      "That soil near your landing site — extraordinary nutrients. Here, take these seeds.",
      "Water every morning, check every evening. Crops are like friendships. They notice neglect.",
      "Good harvest means good winter. I've lived that lesson twice the hard way.",
    ],
  },

  {
    id:'doran', name:'Master Doran', romanceable:false, gender:'M',
    role:'Head blacksmith, gruff but fair',
    skin:6, hairStyle:1, hairColor:15, eyeColor:2, feature:6, earFeather:0,
    suitColor:7, suitTrim:1, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:360, x:36, y:47, dir:2},
      {startMin:1080, x:50, y:41, dir:2},
      {startMin:1200, x:36, y:47, dir:0},
    ],
    dialogue:[
      "You need tools? Come to the smithy. I don't do favours but I do good work.",
      "Caspian's a pain but he's got hands for the forge. He'll be fine.",
      "Forty years at this anvil. My arms are mostly iron at this point.",
    ],
  },

  {
    id:'wren', name:'Wren', romanceable:false, gender:'F',
    role:'Baker, morning person, aggressively cheerful',
    skin:3, hairStyle:8, hairColor:4, eyeColor:1, feature:6, earFeather:0,
    suitColor:2, suitTrim:6, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:240, x:61, y:63, dir:2},
      {startMin:480, x:50, y:41, dir:2},
      {startMin:600, x:61, y:63, dir:2},
      {startMin:1080, x:50, y:41, dir:1},
    ],
    dialogue:[
      "I'm up at 4am every day. Some people think that's insane. Those people are wrong.",
      "Fresh bread in the bakery by sunrise. Don't be late, it goes fast.",
      "You look tired. Have a roll. Everything is better with bread, I stand by that.",
    ],
  },

  {
    id:'aster', name:'Aster', romanceable:false, gender:'F',
    role:'Apothecary, herb-collector, mysteriously knowledgeable',
    skin:11, hairStyle:3, hairColor:8, eyeColor:7, feature:6, earFeather:2,
    suitColor:0, suitTrim:4, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:540, x:74, y:47, dir:2},
      {startMin:720, x:55, y:75, dir:2},
      {startMin:960, x:74, y:47, dir:2},
      {startMin:1200, x:74, y:47, dir:0},
    ],
    dialogue:[
      "The frost in the deep forest is not natural. I know things about it. Come back when you're ready.",
      "These herbs grow only at the forest edge. Useful for many things I shan't list in public.",
      "You carry something unusual in your energy. Not bad. Just... new.",
    ],
  },

  {
    id:'mira', name:'Mira', romanceable:false, gender:'F',
    role:'Young mother, community organizer, practical and sharp',
    skin:4, hairStyle:4, hairColor:3, eyeColor:0, feature:3, earFeather:1,
    suitColor:2, suitTrim:0, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:360, x:22, y:63, dir:2},
      {startMin:540, x:50, y:41, dir:2},
      {startMin:720, x:22, y:63, dir:0},
      {startMin:1080, x:50, y:41, dir:1},
    ],
    dialogue:[
      "Welcome to Fernhaven. If you need anything — food, help, information — just ask.",
      "The town meetings are the third Sunday of each month. Show up. It matters.",
      "We've had strange visitors before. None from as far as you, though.",
    ],
  },

  {
    id:'kael', name:'Elder Kael', romanceable:false, gender:'M',
    role:'Town elder, historian, probably knows more than he says',
    skin:10, hairStyle:1, hairColor:7, eyeColor:5, feature:6, earFeather:0,
    suitColor:1, suitTrim:1, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:600, x:35, y:63, dir:2},
      {startMin:900, x:50, y:41, dir:2},
      {startMin:1140, x:35, y:63, dir:0},
    ],
    dialogue:[
      "This town has stood two hundred years. Many things have passed through. Few as interesting as you.",
      "The frost? I've seen it before. Long ago. Ask me again when the time is right.",
      "Sit with an old man. The best conversations take patience.",
    ],
  },

  {
    id:'rancher', name:'Corin', romanceable:false, gender:'M',
    role:'Rancher, animal whisperer, soft-spoken',
    skin:0, hairStyle:5, hairColor:1, eyeColor:2, feature:6, earFeather:0,
    suitColor:5, suitTrim:2, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:300, x:35, y:36, dir:2},
      {startMin:720, x:50, y:41, dir:2},
      {startMin:900, x:35, y:36, dir:2},
    ],
    dialogue:[
      "The chickens were unsettled the night you landed. Animals always know first.",
      "I've a spare hen if you want to start keeping animals. She's calm. She'll like you.",
      "Ranching teaches patience better than anything. You wait. You watch. You learn.",
    ],
  },

  {
    id:'tavi', name:'Tavi', romanceable:false, gender:'F',
    role:'Innkeeper, warm and unflappable',
    skin:3, hairStyle:0, hairColor:2, eyeColor:1, feature:6, earFeather:0,
    suitColor:3, suitTrim:7, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:420, x:74, y:63, dir:2},
      {startMin:720, x:50, y:41, dir:3},
      {startMin:840, x:74, y:63, dir:2},
      {startMin:1320, x:74, y:63, dir:0},
    ],
    dialogue:[
      "The inn's always open. Hot meals at six, eight, and noon. Don't miss breakfast.",
      "Travellers pass through more than people think. You'd be surprised who ends up here.",
      "I've never left Fernhaven and I have no plans to. Everything interesting comes to me.",
    ],
  },

  {
    id:'juno', name:'Juno', romanceable:false, gender:'F',
    role:'Carpenter\'s daughter, ambitious, wants to travel',
    skin:1, hairStyle:2, hairColor:9, eyeColor:4, feature:1, earFeather:0,
    suitColor:0, suitTrim:5, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:480, x:73, y:36, dir:2},
      {startMin:720, x:55, y:80, dir:2},
      {startMin:1080, x:73, y:36, dir:0},
    ],
    dialogue:[
      "My dad builds things that last a hundred years. I admire that. I just want more.",
      "You came from space. That's wild. Was it beautiful? Before the fire part, I mean.",
      "I'm saving up to go to the capital city. Three more years, maybe two.",
    ],
  },

  {
    id:'otto', name:'Otto', romanceable:false, gender:'M',
    role:'Merchant, travels between towns, brings news',
    skin:7, hairStyle:8, hairColor:13, eyeColor:6, feature:6, earFeather:0,
    suitColor:2, suitTrim:3, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:600, x:50, y:41, dir:2},
      {startMin:900, x:76, y:27, dir:1},
      {startMin:1200, x:50, y:41, dir:2},
    ],
    dialogue:[
      "I travel three towns a week. Heard about you before I even got here.",
      "News from the capital: they're concerned about the northern forest. Won't say why.",
      "Got rare goods from the coast if you're interested. Not cheap, but not cheap things rarely are.",
    ],
  },

  {
    id:'finn', name:'Finn', romanceable:false, gender:'M',
    role:'Teenage kid, curious, rides around town',
    skin:0, hairStyle:7, hairColor:4, eyeColor:0, feature:6, earFeather:0,
    suitColor:0, suitTrim:0, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:480, x:55, y:80, dir:2},
      {startMin:720, x:50, y:41, dir:3},
      {startMin:900, x:88, y:65, dir:2},
      {startMin:1140, x:22, y:47, dir:0},
    ],
    dialogue:[
      "You fell from SPACE! That's literally the coolest thing that has ever happened here.",
      "I've been mapping the forest. Elder Kael told me to stop. I haven't stopped.",
      "Can I see your space suit up close? The visor thing is amazing.",
    ],
  },

  {
    id:'delly', name:'Delly', romanceable:false, gender:'F',
    role:'Retired teacher, sharp memory, loves gossip disguised as wisdom',
    skin:6, hairStyle:9, hairColor:7, eyeColor:5, feature:3, earFeather:1,
    suitColor:4, suitTrim:0, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:600, x:50, y:41, dir:2},
      {startMin:900, x:55, y:80, dir:1},
      {startMin:1140, x:50, y:41, dir:2},
    ],
    dialogue:[
      "I taught every child in this town. Half of them turned out fine.",
      "Thirty years ago something happened in the deep forest. Nobody talks about it.",
      "You remind me of someone who passed through a long time ago. Different species, same eyes.",
    ],
  },

  {
    id:'grove', name:'Grove', romanceable:false, gender:'M',
    role:'Quiet gardener, tends the town square planters',
    skin:11, hairStyle:6, hairColor:0, eyeColor:2, feature:2, earFeather:0,
    suitColor:5, suitTrim:2, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:420, x:54, y:40, dir:2},
      {startMin:720, x:88, y:75, dir:2},
      {startMin:1080, x:54, y:40, dir:0},
    ],
    dialogue:[
      "The plaza planters need water twice a day. People walk past them without looking. You looked.",
      "Every plant in this square has a name. I don't tell anyone the names. They're private.",
      "The river's a good place to think. So is here. Depends what you need to think about.",
    ],
  },

  {
    id:'nessa', name:'Nessa', romanceable:false, gender:'F',
    role:'Brix\'s wife, runs the farm stand, wickedly funny',
    skin:4, hairStyle:3, hairColor:3, eyeColor:1, feature:6, earFeather:0,
    suitColor:2, suitTrim:6, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:480, x:10, y:61, dir:3},
      {startMin:720, x:50, y:41, dir:2},
      {startMin:900, x:10, y:61, dir:2},
    ],
    dialogue:[
      "Brix says the soil near your crash is incredible. I say it better be, for all the drama it caused.",
      "Farm stand's open mornings. Best tomatoes in three valleys and I'll fight anyone who disagrees.",
      "You seem confused. That's normal. It took me a full season to understand Fernhaven too.",
    ],
  },

  {
    id:'pell', name:'Pell', romanceable:false, gender:'M',
    role:'Dock worker, laconic, deeply superstitious',
    skin:8, hairStyle:1, hairColor:1, eyeColor:6, feature:6, earFeather:0,
    suitColor:6, suitTrim:2, heartLevel:0, dlgIdx:0,
    schedule:[
      {startMin:300, x:88, y:91, dir:2},
      {startMin:720, x:50, y:41, dir:2},
      {startMin:900, x:88, y:91, dir:2},
    ],
    dialogue:[
      "Don't whistle on the dock. Bad luck.",
      "Saw something big in the river three nights back. Wasn't a fish.",
      "You came from the sky. In this town, that means something. Ask Elder Kael.",
    ],
  },

];

// ── Build NPC state from defs ──────────────────────────
NPCS.spawn = () => {
  return NPCS.defs.map(def => {
    const sched = def.schedule[0];
    return {
      ...def,
      x: sched.x * C.TS + C.TS/2,
      y: sched.y * C.TS + C.TS/2,
      dir: sched.dir,
      frame: 0,
      frameTick: 0,
      walkTick: 0,
      walkDX: 0,
      walkDY: 0,
      walkTime: 0,
      idleTick: 0,
      schedIdx: 0,
      moving: false,
    };
  });
};

// ── Get current schedule target for an NPC ────────────
NPCS.getSchedTarget = (npc, gmin) => {
  let best = npc.schedule[0];
  for(const s of npc.schedule) {
    if(gmin >= s.startMin) best = s;
  }
  return best;
};
