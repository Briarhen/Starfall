// ═══════════════════════════════════════════════════════
//  DIALOGUE SYSTEM
// ═══════════════════════════════════════════════════════

const DLG = {
  active: false,
  queue: [],
  idx: 0,
  typing: false,
  typeTimer: null,
  currentNPC: null,
};

DLG.show = (queue, npc=null) => {
  DLG.queue = queue;
  DLG.idx = 0;
  DLG.active = true;
  DLG.currentNPC = npc;
  DLG.showLine();
};

DLG.showLine = () => {
  if(DLG.idx >= DLG.queue.length) { DLG.close(); return; }
  const [speaker, text] = DLG.queue[DLG.idx];
  DLG.idx++;

  document.getElementById('dlg-box').classList.remove('hidden');
  document.getElementById('dlg-name').textContent = speaker.toUpperCase();

  // Portrait
  const npc = DLG.currentNPC;
  const pc = document.getElementById('dlg-portrait-canvas');
  const pctx = pc.getContext('2d');
  if(npc) {
    pctx.clearRect(0,0,48,64);
    pctx.fillStyle = '#0e0820';
    pctx.fillRect(0,0,48,64);
    drawCharacter(pctx, 0, 0, npc, 2, 0, 1);
  } else {
    pctx.clearRect(0,0,48,64);
    pctx.fillStyle = '#0e0820';
    pctx.fillRect(0,0,48,64);
    drawCharacter(pctx, 0, 0, G.player, 2, 0, 1);
  }

  // Type text
  const el = document.getElementById('dlg-text');
  el.textContent = '';
  if(DLG.typeTimer) clearInterval(DLG.typeTimer);
  DLG.typing = true;
  let i = 0;
  DLG.typeTimer = setInterval(() => {
    el.textContent += text[i++];
    if(i >= text.length) { clearInterval(DLG.typeTimer); DLG.typing = false; }
  }, 20);
};

DLG.advance = () => {
  if(!DLG.active) return;
  if(DLG.typing) {
    // Skip typing — show full text
    clearInterval(DLG.typeTimer);
    DLG.typing = false;
    const [, text] = DLG.queue[DLG.idx-1] || [];
    if(text) document.getElementById('dlg-text').textContent = text;
    return;
  }
  DLG.showLine();
};

DLG.close = () => {
  DLG.active = false;
  DLG.currentNPC = null;
  document.getElementById('dlg-box').classList.add('hidden');
};
