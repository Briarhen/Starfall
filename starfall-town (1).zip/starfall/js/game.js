// ═══════════════════════════════════════════════════════
//  GAME CONTROLLER
// ═══════════════════════════════════════════════════════

const G = {
  player: {
    x: 52 * 24 + 12,   // start near town center
    y: 42 * 24 + 12,
    dir: 2, frame: 0, frameTick: 0, moving: false,
    name: 'Lyra',
    skin:2, hairStyle:9, hairColor:10, eyeColor:4,
    feature:1, earFeather:2, suitColor:0, suitTrim:0,
  },
  world: { day:1, gmin:480, season:'Spring' }, // 8am start
  camera: { x:0, y:0 },
  npcs: [],
  tick: 0,
  notifTimer: null,
  interactCooldown: 0,
  passedOut: false,
  running: false,
};

// ── INIT ─────────────────────────────────────────────
G.init = async () => {
  const steps = [
    ['Building town map...', () => TM.build()],
    ['Summoning citizens...', () => { G.npcs = NPCS.spawn(); }],
    ['Setting up renderer...', () => {
      const canvas = document.getElementById('gc');
      canvas.width = C.VW; canvas.height = C.VH;
      R.init(canvas);
    }],
    ['Placing your character...', () => G.updateCamera()],
    ['Opening the gates...', () => {}],
  ];

  for(let i=0; i<steps.length; i++) {
    const [msg, fn] = steps[i];
    G.setLoadStatus(msg, (i+1)/steps.length);
    await G.sleep(300);
    fn();
  }

  await G.sleep(400);
  G.fadeOutLoader();
};

G.setLoadStatus = (msg, pct) => {
  document.getElementById('load-status').textContent = msg;
  document.getElementById('load-bar').style.width = (pct * 100) + '%';
};

G.sleep = (ms) => new Promise(r => setTimeout(r, ms));

G.fadeOutLoader = () => {
  const loader = document.getElementById('loader');
  loader.classList.add('fade');
  setTimeout(() => {
    loader.style.display = 'none';
    document.getElementById('game-wrap').style.display = 'block';
    document.getElementById('hud').classList.remove('hidden');
    document.getElementById('minimap-wrap').classList.remove('hidden');
    G.showIntroDialogue();
    G.running = true;
    G.loop();
  }, 900);
};

G.showIntroDialogue = () => {
  DLG.show([
    ['Dr. Maren', "Somehow you're not hurt. Whatever you are, you're built differently."],
    ['Dr. Maren', "The tavern is just north of here, past the main plaza. Follow the cobblestone path."],
    [G.player.name, "...Where am I?"],
    ['Dr. Maren', "Fernhaven. And yes — you're welcome to stay as long as you need."],
  ], G.npcs.find(n=>n.id==='maren'));
};

// ── GAME LOOP ─────────────────────────────────────────
G.loop = () => {
  if(!G.running) return;
  requestAnimationFrame(G.loop);
  G.tick++;

  if(!G.passedOut) {
    G.handleMovement();
    G.updateNPCs();
    G.updateTime();
    G.updateInteractHint();
  }

  R.render(G);
  R.renderMinimap(G);
  G.updateHUD();
};

// ── MOVEMENT ─────────────────────────────────────────
G.handleMovement = () => {
  if(DLG.active) return;
  const {dx, dy} = INPUT.getAxes();
  const moving = dx !== 0 || dy !== 0;
  G.player.moving = moving;

  if(moving) {
    // Direction
    if(dy < 0) G.player.dir = 0;
    else if(dy > 0) G.player.dir = 2;
    else if(dx < 0) G.player.dir = 1;
    else G.player.dir = 3;

    // Walk animation — Harvest Moon style: 4 frames, swap every 10 ticks
    G.player.frameTick++;
    if(G.player.frameTick >= 10) {
      G.player.frameTick = 0;
      G.player.frame = (G.player.frame % 2) + 1; // cycles 1,2,1,2
    }

    const spd = C.PLAYER_SPEED;
    // Pixel-by-pixel movement with collision on tile grid
    const nx = G.player.x + dx * spd;
    const ny = G.player.y + dy * spd;

    // Check collision using 4-corner bounding box (8px radius)
    const R = 7; // half-width of character footprint
    const canMoveX = !G.collidesAt(nx + R * Math.sign(dx), G.player.y);
    const canMoveY = !G.collidesAt(G.player.x, ny + R * Math.sign(dy));

    if(canMoveX) G.player.x = nx;
    if(canMoveY) G.player.y = ny;

    // Clamp to map
    G.player.x = Math.max(C.TS, Math.min((C.MAP_W-1)*C.TS, G.player.x));
    G.player.y = Math.max(C.TS, Math.min((C.MAP_H-1)*C.TS, G.player.y));
  } else {
    G.player.frame = 0;
    G.player.frameTick = 0;
  }

  G.updateCamera();
  if(G.interactCooldown > 0) G.interactCooldown--;
};

G.collidesAt = (wx, wy) => {
  const tx = Math.floor(wx / C.TS);
  const ty = Math.floor(wy / C.TS);
  return TM.isSolid(tx, ty);
};

G.updateCamera = () => {
  G.camera.x = Math.max(0, Math.min(C.MAP_W * C.TS - C.VW, G.player.x - C.VW/2));
  G.camera.y = Math.max(0, Math.min(C.MAP_H * C.TS - C.VH, G.player.y - C.VH/2));
};

// ── NPC AI ────────────────────────────────────────────
G.updateNPCs = () => {
  G.npcs.forEach(npc => {
    // Schedule-driven: move toward schedule target position
    const target = NPCS.getSchedTarget(npc, G.world.gmin);
    const targetX = target.x * C.TS + C.TS/2;
    const targetY = target.y * C.TS + C.TS/2;

    const distToTarget = Math.hypot(npc.x - targetX, npc.y - targetY);

    // Wander near target if close, pathfind toward if far
    npc.walkTick = (npc.walkTick || 0) - 1;

    if(distToTarget > 48) {
      // Move toward schedule target
      const dx = targetX - npc.x;
      const dy = targetY - npc.y;
      const len = Math.hypot(dx, dy);
      const spd = 0.6;
      const mx = (dx/len)*spd, my = (dy/len)*spd;

      // Direction
      if(Math.abs(my) > Math.abs(mx)) npc.dir = my>0?2:0;
      else npc.dir = mx>0?3:1;

      if(!G.collidesAt(npc.x + mx*2, npc.y)) npc.x += mx;
      if(!G.collidesAt(npc.x, npc.y + my*2)) npc.y += my;
      npc.moving = true;
    } else {
      // Idle wander
      if(npc.walkTick <= 0) {
        npc.walkTick = 80 + Math.random()*120;
        const r = Math.random();
        if(r < 0.4) {
          npc.walkDX = 0; npc.walkDY = 0; npc.walkTime = 0;
        } else {
          const d = Math.floor(Math.random()*4);
          npc.walkDX = d===3?1:d===1?-1:0;
          npc.walkDY = d===2?1:d===0?-1:0;
          npc.walkTime = 30 + Math.random()*60;
          if(npc.walkDY<0) npc.dir=0; else if(npc.walkDY>0) npc.dir=2;
          else if(npc.walkDX<0) npc.dir=1; else npc.dir=3;
        }
      }
      if((npc.walkTime||0) > 0) {
        npc.walkTime--;
        const spd = 0.5;
        const nx = npc.x + (npc.walkDX||0)*spd;
        const ny = npc.y + (npc.walkDY||0)*spd;
        if(!G.collidesAt(nx, ny)) { npc.x=nx; npc.y=ny; }
        npc.moving = true;
      } else {
        npc.moving = false;
        npc.dir = target.dir;
      }
    }

    // Animation — same Harvest Moon 1/2 cycle
    if(npc.moving) {
      npc.frameTick = (npc.frameTick||0) + 1;
      if(npc.frameTick >= 12) {
        npc.frameTick = 0;
        npc.frame = (npc.frame%2)+1;
      }
    } else {
      npc.frame = 0;
    }
  });
};

// ── TIME ──────────────────────────────────────────────
G.updateTime = () => {
  if(G.tick % C.TICKS_PER_GMIN !== 0) return;
  G.world.gmin++;
  if(G.world.gmin >= 1440) {
    G.world.gmin = 360;
    G.world.day++;
  }
  // Season
  G.world.season = C.SEASONS[Math.floor((G.world.day-1)/28) % 4];

  // Warnings and passout
  if(G.world.gmin === 1320) G.notify("You're getting tired...", 5000);
  if(G.world.gmin === 1380) G.triggerPassout();
};

G.triggerPassout = () => {
  if(G.passedOut) return;
  G.passedOut = true;
  const ov = document.getElementById('passout-screen');
  const msg = document.getElementById('passout-msg');
  ov.classList.remove('hidden');
  setTimeout(()=> ov.classList.add('active'), 50);
  setTimeout(()=> { msg.textContent = 'You stayed up too late and passed out...'; msg.classList.add('show'); }, 2600);
  setTimeout(()=> {
    G.world.day++;
    G.world.gmin = 420; // wake up at 7am
    G.player.x = 52*C.TS+12; G.player.y = 42*C.TS+12;
    G.updateCamera();
    G.passedOut = false;
    msg.classList.remove('show');
    setTimeout(()=> {
      ov.classList.remove('active');
      setTimeout(()=>{ ov.classList.add('hidden'); DLG.show([[G.player.name,"...I fell asleep out here. A new day."]]); }, 2200);
    }, 1800);
  }, 5000);
};

// ── INTERACT ──────────────────────────────────────────
G.tryInteract = () => {
  if(G.interactCooldown > 0) return;
  // Check NPCs
  const npc = G.npcs.find(n => Math.hypot(n.x-G.player.x, n.y-G.player.y) < C.INTERACT_RANGE);
  if(npc) {
    const line = npc.dialogue[npc.dlgIdx % npc.dialogue.length];
    npc.dlgIdx++;
    // Face player
    const dx=G.player.x-npc.x, dy=G.player.y-npc.y;
    npc.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?3:1):(dy>0?2:0);
    DLG.show([[npc.name, line]], npc);
    G.interactCooldown = 30;
    return;
  }
  // Check building doors
  const playerTX = Math.floor(G.player.x/C.TS);
  const playerTY = Math.floor(G.player.y/C.TS);
  const door = TM.buildingDoors.find(d => Math.abs(d.x-playerTX)<=1 && Math.abs(d.y-playerTY)<=1);
  if(door) {
    G.notify(`Entering ${door.label}...`, 1500);
    G.interactCooldown = 60;
  }
};

G.updateInteractHint = () => {
  const hint = document.getElementById('interact-hint');
  const nameEl = document.getElementById('interact-name');
  const npc = G.npcs.find(n => Math.hypot(n.x-G.player.x, n.y-G.player.y) < C.INTERACT_RANGE);
  if(npc && !DLG.active) {
    hint.classList.remove('hidden');
    nameEl.textContent = npc.name + ' ';
  } else {
    hint.classList.add('hidden');
  }
};

// ── HUD ───────────────────────────────────────────────
G.updateHUD = () => {
  const h = Math.floor(G.world.gmin/60)%24;
  const m = Math.floor(G.world.gmin%60);
  const ap = h>=12?'PM':'AM';
  const dh = h%12||12;
  document.getElementById('hud-time').textContent =
    `Day ${G.world.day}  ·  ${dh}:${String(m).padStart(2,'0')} ${ap}`;
  document.getElementById('hud-season').textContent =
    `✦ ${G.world.season}`;
};

// ── NOTIFY ────────────────────────────────────────────
G.notify = (text, dur=3000) => {
  const el = document.getElementById('notif');
  el.textContent = text;
  el.classList.remove('hidden');
  if(G.notifTimer) clearTimeout(G.notifTimer);
  G.notifTimer = setTimeout(() => el.classList.add('hidden'), dur);
};

// ── BOOT ──────────────────────────────────────────────
window.addEventListener('load', () => {
  G.init();
});
