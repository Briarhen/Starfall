// ═══════════════════════════════════════════════════════
//  CONSTANTS
// ═══════════════════════════════════════════════════════

const C = {
  // Canvas / viewport
  VW: 768, VH: 576,
  // Tile size in world pixels (Harvest Moon DS style — 24px tiles, 2x render)
  TS: 24,
  // Map dimensions
  MAP_W: 120, MAP_H: 100,

  // Time: 20 real minutes = full day. 1440 game-minutes/day.
  // At 60fps: 1200 real-seconds * 60 = 72000 ticks/day
  // ticks per game-minute = 72000/1440 = 50
  TICKS_PER_GMIN: 50,

  // Player
  PLAYER_SPEED: 1.6,
  INTERACT_RANGE: 38,

  // Tile IDs
  T: {
    GRASS:0, PATH:1, WATER:2, WALL:3, TREE:4, FLOWER:5,
    CROP:6, FENCE:7, TALL_GRASS:8, DOCK:9, SAND:10,
    COBBLE:11, BUSH:12, TREE2:13, PLANTER:14, CLIFF:15,
    BUILDING_FLOOR:16, DOOR:17, SIGN:18, BRIDGE:19,
    DEEP_WATER:20, SHALLOW:21, ROCK:22, LOG:23,
    GRAVEL:24, DARK_GRASS:25,
  },

  // Colour palettes
  SKIN: [
    '#f8d4a0','#f0c080','#e0a860','#c88840',
    '#a86830','#804820','#c0d8c0','#a0c8e0',
    '#d0b0e8','#e8d890','#c0e8a0','#f8c0b0'
  ],
  HAIR: [
    '#180800','#3c1c00','#603010','#9a6030',
    '#d09040','#ece060','#f8f0c0','#ffffff',
    '#e04040','#e880b0','#80b0f0','#70d898',
    '#b050f0','#3050d0','#787878','#282828'
  ],
  EYES: [
    '#50a8f8','#f870a8','#68f898','#f8c840',
    '#b868f8','#f86840','#30d0d0','#f8f8f8',
    '#f03030','#30f870'
  ],
  SUIT_MAIN: [
    '#d8eef8','#c0ceea','#ead0c0','#c0ead0',
    '#ead0e8','#f2f0c0','#1c2840','#1c201c'
  ],
  SUIT_TRIM: [
    '#50a0f8','#f85888','#50d898','#f89830',
    '#b850f8','#f83050','#30ccf8','#f8f830'
  ],

  // Seasons
  SEASONS: ['Spring','Summer','Autumn','Winter'],
};

// Tile colours for rendering (base colours)
const TILE_COL = {
  [C.T.GRASS]:       '#5aaa2a',
  [C.T.PATH]:        '#c8a850',
  [C.T.WATER]:       '#2868c0',
  [C.T.WALL]:        '#807060',
  [C.T.TREE]:        '#286820',
  [C.T.FLOWER]:      '#e85898',
  [C.T.CROP]:        '#58a810',
  [C.T.FENCE]:       '#987840',
  [C.T.TALL_GRASS]:  '#409020',
  [C.T.DOCK]:        '#988050',
  [C.T.SAND]:        '#d8c878',
  [C.T.COBBLE]:      '#a09080',
  [C.T.BUSH]:        '#309828',
  [C.T.TREE2]:       '#207020',
  [C.T.PLANTER]:     '#806050',
  [C.T.CLIFF]:       '#786858',
  [C.T.BUILDING_FLOOR]: '#d0c8b8',
  [C.T.DOOR]:        '#8060a0',
  [C.T.SIGN]:        '#b89060',
  [C.T.BRIDGE]:      '#c0a060',
  [C.T.DEEP_WATER]:  '#1848a0',
  [C.T.SHALLOW]:     '#50a8d8',
  [C.T.ROCK]:        '#909090',
  [C.T.LOG]:         '#a07040',
  [C.T.GRAVEL]:      '#b0a898',
  [C.T.DARK_GRASS]:  '#388018',
};

// Which tiles block movement
const SOLID = new Set([
  C.T.WALL, C.T.TREE, C.T.TREE2, C.T.WATER, C.T.DEEP_WATER,
  C.T.FENCE, C.T.BUSH, C.T.PLANTER, C.T.CLIFF, C.T.ROCK, C.T.LOG
]);
