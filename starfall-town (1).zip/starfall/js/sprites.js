// ═══════════════════════════════════════════════════════
//  SPRITES  —  Harvest Moon DS style (24×32 base, 2x render = 48×64 on screen)
//  Directions: 0=up, 1=left, 2=down, 3=right
//  Walk frames: 0=idle, 1=step-a, 2=step-b
// ═══════════════════════════════════════════════════════

const SPR = {};

// px() helper — fill one sprite pixel
function px(ctx, ox, oy, x, y, col, s=2) {
  ctx.fillStyle = col;
  ctx.fillRect(ox + x*s, oy + y*s, s, s);
}
function block(ctx, ox, oy, x, y, w, h, col, s=2) {
  ctx.fillStyle = col;
  ctx.fillRect(ox + x*s, oy + y*s, w*s, h*s);
}

// ── DRAW FULL CHARACTER ──────────────────────────────────
// p = player/npc data object
// scale = pixel multiplier (2 = 48×64 rendered)
function drawCharacter(ctx, ox, oy, p, dir=2, frame=0, scale=2) {
  const s = scale;
  const sk = C.SKIN[p.skin]  || '#e0a860';
  const hc = C.HAIR[p.hairColor] || '#3c1c00';
  const ec = C.EYES[p.eyeColor]  || '#50a8f8';
  const sm = C.SUIT_MAIN[p.suitColor] || '#d8eef8';
  const st = C.SUIT_TRIM[p.suitTrim]  || '#50a0f8';
  const smD = shade(sm, 0.75);
  const stD = shade(st, 0.7);
  const hcD = shade(hc, 0.7);

  // Walk offsets for legs
  const lA = (frame===1) ? -1 : (frame===2 ? 1 : 0);
  const lB = -lA;

  // ── SHADOW ──
  ctx.fillStyle = 'rgba(0,0,0,0.18)';
  ctx.beginPath();
  ctx.ellipse(ox + 12*s, oy + 31*s, 9*s, 3*s, 0, 0, Math.PI*2);
  ctx.fill();

  // ── LEGS ──
  if(dir !== 0) { // front/sides show legs
    block(ctx,ox,oy, 8,22, 4,10, sm, s);   // left leg
    block(ctx,ox,oy, 12,22, 4,10, sm, s);  // right leg
    block(ctx,ox,oy, 9,23, 2,7, smD, s);   // left shadow
    block(ctx,ox,oy, 13,23, 2,7, smD, s);  // right shadow
    // boots
    block(ctx,ox,oy, 7,30, 6,3, '#303050', s);
    block(ctx,ox,oy, 12,30, 5,3, '#303050', s);
    // leg trim stripe
    block(ctx,ox,oy, 8,24, 1,5, st, s);
    block(ctx,ox,oy, 12,24, 1,5, st, s);
    // walk animation
    if(frame > 0) {
      // re-draw with offsets
      ctx.clearRect(ox+7*s, oy+22*s, 10*s, 12*s);
      ctx.fillStyle = '#5aaa2a'; ctx.fillRect(ox+7*s, oy+22*s, 10*s, 12*s); // clear to bg (will be covered)
      block(ctx,ox,oy, 8,22+lA, 4,10, sm, s);
      block(ctx,ox,oy, 12,22+lB, 4,10, sm, s);
      block(ctx,ox,oy, 9,23+lA, 2,7, smD, s);
      block(ctx,ox,oy, 13,23+lB, 2,7, smD, s);
      block(ctx,ox,oy, 7,30+lA, 6,3, '#303050', s);
      block(ctx,ox,oy, 12,30+lB, 5,3, '#303050', s);
      block(ctx,ox,oy, 8,24+lA, 1,5, st, s);
      block(ctx,ox,oy, 12,24+lB, 1,5, st, s);
    }
  } else {
    // back view legs
    block(ctx,ox,oy, 8,22, 4,9, smD, s);
    block(ctx,ox,oy, 12,22, 4,9, smD, s);
    block(ctx,ox,oy, 7,30, 6,3, '#252540', s);
    block(ctx,ox,oy, 12,30, 5,3, '#252540', s);
  }

  // ── BODY / SUIT ──
  block(ctx,ox,oy, 5,12, 14,11, sm, s);   // torso
  block(ctx,ox,oy, 6,13, 12,9, smD, s);   // torso shade sides
  block(ctx,ox,oy, 7,13, 10,8, sm, s);    // torso center (lighter)
  // chest highlight
  block(ctx,ox,oy, 8,14, 8,5, shade(sm,1.08), s);
  // belt
  block(ctx,ox,oy, 5,21, 14,2, st, s);
  block(ctx,ox,oy, 10,21, 4,2, shade(st,1.2), s);
  // collar/trim
  block(ctx,ox,oy, 5,12, 14,2, st, s);
  // chest badge (glowing)
  ctx.fillStyle = ec;
  ctx.beginPath(); ctx.arc(ox+8*s, oy+16*s, 1.5*s, 0, Math.PI*2); ctx.fill();
  // chest panel lines
  block(ctx,ox,oy, 9,15, 6,1, shade(sm,0.85), s);
  block(ctx,ox,oy, 9,17, 6,1, shade(sm,0.85), s);
  block(ctx,ox,oy, 9,19, 6,1, shade(sm,0.85), s);

  // ── ARMS ──
  if(dir !== 0) {
    block(ctx,ox,oy, 1,13, 5,10, sm, s);  // left arm
    block(ctx,ox,oy, 18,13, 5,10, sm, s); // right arm
    block(ctx,ox,oy, 2,14, 2,7, smD, s);
    block(ctx,ox,oy, 20,14, 2,7, smD, s);
    // gloves
    block(ctx,ox,oy, 1,22, 5,3, '#2a2848', s);
    block(ctx,ox,oy, 18,22, 5,3, '#2a2848', s);
    // arm trim
    block(ctx,ox,oy, 1,13, 1,9, st, s);
    block(ctx,ox,oy, 22,13, 1,9, st, s);
  } else {
    block(ctx,ox,oy, 1,13, 4,10, smD, s);
    block(ctx,ox,oy, 19,13, 4,10, smD, s);
    block(ctx,ox,oy, 1,22, 4,3, '#252540', s);
    block(ctx,ox,oy, 19,22, 4,3, '#252540', s);
  }

  // ── HELMET RING / NECK ──
  block(ctx,ox,oy, 7,9, 10,4, st, s);
  block(ctx,ox,oy, 8,10, 8,3, shade(st,0.8), s);

  // ── HEAD (skin under visor area) ──
  block(ctx,ox,oy, 6,1, 12,10, sk, s);
  // head shading
  block(ctx,ox,oy, 6,1, 2,10, shade(sk,0.88), s);
  block(ctx,ox,oy, 16,1, 2,10, shade(sk,0.88), s);

  // ── HELMET ──
  // dome
  block(ctx,ox,oy, 5,0, 14,12, sm, s);
  block(ctx,ox,oy, 6,0, 12,11, shade(sm,1.05), s);
  // visor
  block(ctx,ox,oy, 6,3, 12,6, '#0a1428', s);
  // visor glass tint
  block(ctx,ox,oy, 6,3, 12,6, 'rgba(30,60,120,0.5)', s);
  // visor shine
  block(ctx,ox,oy, 7,4, 4,2, 'rgba(180,220,255,0.35)', s);
  // visor rim
  block(ctx,ox,oy, 6,3, 12,1, st, s);
  block(ctx,ox,oy, 6,8, 12,1, st, s);
  block(ctx,ox,oy, 6,3, 1,6, st, s);
  block(ctx,ox,oy, 17,3, 1,6, st, s);
  // helmet top plate
  block(ctx,ox,oy, 5,0, 14,2, shade(sm,0.9), s);
  block(ctx,ox,oy, 6,0, 12,1, shade(sm,1.1), s);

  // ── EYES (in visor) ──
  if(dir === 2) { // front
    block(ctx,ox,oy, 8,5, 3,2, ec, s);
    block(ctx,ox,oy, 13,5, 3,2, ec, s);
    px(ctx,ox,oy, 9,5, 'rgba(0,0,0,0.6)', s);
    px(ctx,ox,oy, 14,5, 'rgba(0,0,0,0.6)', s);
    px(ctx,ox,oy, 8,5, 'rgba(255,255,255,0.9)', s);
    px(ctx,ox,oy, 13,5, 'rgba(255,255,255,0.9)', s);
    // lower eyelid
    block(ctx,ox,oy, 8,7, 3,1, shade(ec,0.7), s);
    block(ctx,ox,oy, 13,7, 3,1, shade(ec,0.7), s);
  } else if(dir === 1) { // left
    block(ctx,ox,oy, 7,5, 3,2, ec, s);
    px(ctx,ox,oy, 8,5, 'rgba(0,0,0,0.6)', s);
    px(ctx,ox,oy, 7,5, 'rgba(255,255,255,0.9)', s);
  } else if(dir === 3) { // right
    block(ctx,ox,oy, 14,5, 3,2, ec, s);
    px(ctx,ox,oy, 15,5, 'rgba(0,0,0,0.6)', s);
    px(ctx,ox,oy, 14,5, 'rgba(255,255,255,0.9)', s);
  }
  // facing up — no eyes visible (back of helmet)

  // ── HAIR (pokes out of/over helmet) ──
  drawHair(ctx, ox, oy, s, p.hairStyle || 0, hc, hcD, dir);

  // ── ALIEN FEATURE ──
  if(p.feature !== undefined) drawFeature(ctx, ox, oy, s, p.feature, sk, ec, dir);

  // ── EAR FEATHERS ──
  if(p.earFeather > 0) drawEarFeather(ctx, ox, oy, s, p.earFeather, hc, hcD);
}

function shade(hex, factor) {
  if(!hex || hex[0] !== '#') return hex;
  const r = parseInt(hex.slice(1,3),16);
  const g = parseInt(hex.slice(3,5),16);
  const b = parseInt(hex.slice(5,7),16);
  const rr = Math.min(255,Math.round(r*factor));
  const gg = Math.min(255,Math.round(g*factor));
  const bb = Math.min(255,Math.round(b*factor));
  return `rgb(${rr},${gg},${bb})`;
}

function drawHair(ctx, ox, oy, s, style, hc, hcD, dir) {
  const b = (x,y,w,h,c=hc)=>block(ctx,ox,oy,x,y,w,h,c,s);
  switch(style) {
    case 0: // Bun
      b(7,-2,10,3); b(9,-4,6,3); b(10,-5,4,2);
      b(5,0,14,2,hcD); break;
    case 1: // Short cropped
      b(5,0,14,3); b(5,0,2,5,hcD); b(17,0,2,5,hcD);
      b(6,1,3,2,shade(hc,1.1)); break;
    case 2: // Curly / afro
      ctx.fillStyle = hc;
      ctx.beginPath(); ctx.arc(ox+12*s, oy+0, 8*s, Math.PI, 0, false); ctx.fill();
      ctx.beginPath(); ctx.arc(ox+6*s, oy+3*s, 5*s, Math.PI, 0, false); ctx.fill();
      ctx.beginPath(); ctx.arc(ox+18*s, oy+3*s, 5*s, Math.PI, 0, false); ctx.fill();
      ctx.fillStyle = hcD;
      ctx.beginPath(); ctx.arc(ox+12*s, oy+1*s, 5*s, Math.PI, 0, false); ctx.fill();
      break;
    case 3: // Straight long
      b(5,0,14,3); b(4,1,3,16,hcD); b(17,1,3,16,hcD);
      b(5,1,3,12); b(16,1,3,12);
      b(5,0,14,1,shade(hc,1.15)); break;
    case 4: // Ponytail
      b(5,0,14,3); b(5,0,2,5,hcD); b(17,0,2,5,hcD);
      b(19,0,4,20); b(19,18,3,6,hcD); b(19,22,2,4,shade(hc,0.6)); break;
    case 5: // Braids
      b(5,0,14,3);
      for(let i=0;i<4;i++){
        b(6+i*3,3,2,20,i%2===0?hc:hcD);
        if(i<3) b(7+i*3,21,1,4,shade(hc,0.6));
      } break;
    case 6: // Locs
      b(5,0,14,3);
      b(4,2,3,18,hcD); b(17,2,3,18,hcD);
      b(7,3,2,16); b(11,3,2,14); b(15,3,2,16);
      b(9,3,2,12,shade(hc,0.85)); break;
    case 7: // Mohawk
      b(10,-5,4,6); b(9,-3,6,4); b(10,-2,4,4,hcD);
      b(8,0,8,2); break;
    case 8: // Pixie
      b(5,0,14,4); b(5,0,2,6,hcD); b(17,0,2,4,hcD);
      b(6,3,5,3,hcD); b(5,0,14,1,shade(hc,1.2)); break;
    case 9: // Wavy Bob
      b(5,0,14,3); b(4,2,4,10,hcD); b(16,2,4,10,hcD);
      b(5,3,4,8); b(15,3,4,8);
      b(5,10,14,3,hcD); b(6,11,12,2,shade(hc,0.65)); break;
    case 10: // Twin buns
      b(5,0,14,3);
      b(4,-3,7,5); b(5,-5,5,3); b(15,-3,6,5); b(15,-5,5,3);
      b(5,-2,5,2,hcD); b(15,-2,5,2,hcD); break;
    case 11: // Updo
      b(5,0,14,3,hcD); b(7,-4,10,5); b(8,-6,8,3); b(9,-7,6,2);
      b(5,0,2,6,hcD); b(17,0,2,6,hcD); break;
  }
}

function drawFeature(ctx, ox, oy, s, feature, sk, ec, dir) {
  const b = (x,y,w,h,c)=>block(ctx,ox,oy,x,y,w,h,c,s);
  switch(feature) {
    case 0: // Horns
      b(6,-6,3,7,'#c0a0f0'); b(15,-6,3,7,'#c0a0f0');
      b(7,-8,2,3,'#a080d8'); b(16,-8,2,3,'#a080d8');
      b(8,-9,1,2,'#8060c0'); b(17,-9,1,2,'#8060c0'); break;
    case 1: // Face feathers (outside visor on cheeks)
      for(let i=0;i<4;i++){
        b(2,4+i*2,4,2,'#f890c0');
        b(18,4+i*2,4,2,'#f890c0');
      }
      b(1,5,3,5,'#f070b0'); b(20,5,3,5,'#f070b0'); break;
    case 2: // Kelp fronds
      for(let i=0;i<5;i++){
        const ky = Math.round(Math.sin(i)*1.5);
        b(6+i*2,-5+ky,2,6,'#40c880');
        b(7+i*2,-6+ky,1,4,'#28a860');
      } break;
    case 3: // Pointed ears
      b(3,3,4,8,sk); b(17,3,4,8,sk);
      b(3,3,2,3,sk); b(19,3,2,3,sk); break;
    case 4: // Tail spine (lower body)
      b(11,28,2,8,'#c0a0f0'); b(10,33,4,4,'#a080d8'); b(11,36,2,3,'#8060c0'); break;
    case 5: // Gill slits (neck)
      b(3,10,3,2,'#50c8c0'); b(3,13,3,2,'#50c8c0');
      b(18,10,3,2,'#50c8c0'); b(18,13,3,2,'#50c8c0'); break;
    case 6: break; // None
  }
}

function drawEarFeather(ctx, ox, oy, s, ef, hc, hcD) {
  const b = (x,y,w,h,c)=>block(ctx,ox,oy,x,y,w,h,c,s);
  if(ef===1){ b(3,3,4,6,hc); b(17,3,4,6,hc); }
  else if(ef===2){ b(1,2,5,10,hc); b(18,2,5,10,hc); b(0,3,3,8,hcD); b(21,3,3,8,hcD); }
  else if(ef===3){
    for(let i=0;i<5;i++){
      b(1+i,2+i,4,2,i%2===0?hc:hcD);
      b(18-i,2+i,4,2,i%2===0?hc:hcD);
    }
  }
}

// ── NPC SPRITE (same system but uses npc colour params) ──
function drawNPC(ctx, ox, oy, npc, scale=2) {
  drawCharacter(ctx, ox, oy, npc, npc.dir, npc.frame, scale);
}

// ── PORTRAIT (for dialogue box, 48×64) ──
function drawPortrait(ctx, npc) {
  ctx.clearRect(0,0,48,64);
  ctx.fillStyle = '#0e0820';
  ctx.fillRect(0,0,48,64);
  drawCharacter(ctx, 0, 0, npc, 2, 0, 1);
}
