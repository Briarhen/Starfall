// ═══════════════════════════════════════════════════════
//  TILEMAP  —  Fernhaven, 120×100 tiles
// ═══════════════════════════════════════════════════════

const TM = {};

TM.map = null;          // Uint8Array[MAP_H * MAP_W]
TM.collision = null;    // Uint8Array — 1 = solid
TM.buildingDoors = [];  // { x, y, label, destMap }

TM.get = (x,y) => {
  if(x<0||x>=C.MAP_W||y<0||y>=C.MAP_H) return C.T.WALL;
  return TM.map[y*C.MAP_W + x];
};
TM.set = (x,y,t) => {
  if(x<0||x>=C.MAP_W||y<0||y>=C.MAP_H) return;
  TM.map[y*C.MAP_W + x] = t;
  TM.collision[y*C.MAP_W + x] = SOLID.has(t) ? 1 : 0;
};
TM.fill = (x,y,w,h,t) => { for(let dy=0;dy<h;dy++) for(let dx=0;dx<w;dx++) TM.set(x+dx,y+dy,t); };

TM.isSolid = (x,y) => {
  if(x<0||x>=C.MAP_W||y<0||y>=C.MAP_H) return true;
  return TM.collision[y*C.MAP_W + x] === 1;
};

TM.build = () => {
  const W = C.MAP_W, H = C.MAP_H;
  const T = C.T;
  TM.map = new Uint8Array(W*H);
  TM.collision = new Uint8Array(W*H);
  TM.buildingDoors = [];

  // ── BASE: fill grass ──
  TM.fill(0,0,W,H,T.GRASS);

  // ── CLIFF BORDERS (north & south edges) ──
  TM.fill(0,0,W,4,T.CLIFF);
  TM.fill(0,H-4,W,4,T.CLIFF);
  TM.fill(0,0,4,H,T.CLIFF);
  TM.fill(W-4,0,4,H,T.CLIFF);

  // ── DEEP FOREST (north zone, rows 4–22) ──
  for(let y=4;y<22;y++) for(let x=4;x<W-4;x++) {
    const r = Math.random();
    if(r < 0.52) TM.set(x,y,T.TREE);
    else if(r < 0.62) TM.set(x,y,T.TREE2);
    else if(r < 0.68) TM.set(x,y,T.DARK_GRASS);
    else if(r < 0.72) TM.set(x,y,T.BUSH);
    else TM.set(x,y,T.GRASS);
  }
  // Forest clearings / gaps
  TM.fill(28,8,8,4,T.GRASS); TM.fill(29,9,6,2,T.DARK_GRASS);   // small clearing
  TM.fill(70,6,10,5,T.GRASS); TM.fill(71,7,8,3,T.DARK_GRASS);   // another clearing
  // Forest path (narrow dirt trail from north into town)
  for(let y=4;y<24;y++){ TM.set(52,y,T.PATH); TM.set(53,y,T.PATH); }
  // Forest edge transition (rows 20-24: sparse trees)
  for(let y=20;y<25;y++) for(let x=4;x<W-4;x++) {
    if(TM.get(x,y)===T.TREE || TM.get(x,y)===T.TREE2) {
      if(Math.random()<0.45) TM.set(x,y, Math.random()<0.5?T.BUSH:T.TALL_GRASS);
    }
  }

  // ── WEST FOREST FRINGE (x:4-18, y:24-70) ──
  for(let y=24;y<70;y++) for(let x=4;x<18;x++) {
    const r = Math.random();
    if(r < 0.38) TM.set(x,y,T.TREE);
    else if(r < 0.48) TM.set(x,y,T.BUSH);
    else if(r < 0.55) TM.set(x,y,T.TALL_GRASS);
  }
  // West path clearing
  TM.fill(4,40,14,4,T.GRASS); TM.fill(4,41,13,2,T.DARK_GRASS);

  // ── EAST FOREST FRINGE (x:95-116, y:24-70) ──
  for(let y=24;y<70;y++) for(let x=98;x<W-4;x++) {
    const r = Math.random();
    if(r < 0.35) TM.set(x,y,T.TREE);
    else if(r < 0.45) TM.set(x,y,T.BUSH);
    else if(r < 0.52) TM.set(x,y,T.TALL_GRASS);
  }

  // ── SOUTH AREA (y:70-96): meadow + water ──
  TM.fill(4,70,W-8,26,T.GRASS);
  // Flowers scattered
  const flowerPts = [[20,72],[25,75],[35,78],[42,74],[55,80],[68,76],[80,73],[90,79],[30,85],[60,82],[75,88]];
  flowerPts.forEach(([x,y])=>{ TM.set(x,y,T.FLOWER); TM.set(x+1,y,T.FLOWER); });
  // Tall grass patches (meadow)
  for(let i=0;i<50;i++){
    const x=20+Math.floor(Math.random()*75), y=72+Math.floor(Math.random()*20);
    if(TM.get(x,y)===T.GRASS) TM.set(x,y,T.TALL_GRASS);
  }

  // ── RIVER (east side, y:50-96) ──
  for(let y=50;y<96;y++){
    TM.set(86,y,T.SHALLOW); TM.set(87,y,T.SHALLOW);
    TM.set(88,y,T.WATER); TM.set(89,y,T.WATER); TM.set(90,y,T.WATER);
    TM.set(91,y,T.SHALLOW); TM.set(92,y,T.SHALLOW);
  }
  // River bridge (y:62)
  for(let x=86;x<=92;x++){ TM.set(x,62,T.BRIDGE); TM.set(x,63,T.BRIDGE); }
  // Dock
  TM.fill(88,90,5,4,T.DOCK);

  // ── POND (south-west) ──
  TM.fill(22,78,12,10,T.WATER);
  TM.fill(21,79,14,8,T.WATER);
  TM.fill(23,77,10,1,T.SHALLOW);
  TM.fill(23,88,10,1,T.SHALLOW);
  TM.fill(21,79,1,8,T.SHALLOW);
  TM.fill(34,79,1,8,T.SHALLOW);
  // Pond dock
  TM.fill(26,88,4,3,T.DOCK);

  // ── MAIN ROADS ──
  // Central N-S road (x:48-55)
  TM.fill(48,22,8,52,T.PATH);
  // E-W main road (y:40-43)
  TM.fill(16,40,72,4,T.PATH);
  // E-W upper road (y:30-32)
  TM.fill(16,30,72,3,T.PATH);
  // E-W south road (y:56-58)
  TM.fill(16,56,72,3,T.PATH);
  // N-S east connector (x:80-83)
  TM.fill(80,22,4,52,T.PATH);
  // Plaza / town square
  TM.fill(48,38,16,6,T.COBBLE);
  TM.fill(50,40,12,2,T.COBBLE);
  // Town square decorative planters
  TM.set(50,39,T.PLANTER); TM.set(59,39,T.PLANTER);
  TM.set(50,43,T.PLANTER); TM.set(59,43,T.PLANTER);
  // Signs at road entrances
  TM.set(48,24,T.SIGN); TM.set(80,24,T.SIGN);
  // Cobble around plaza
  TM.fill(46,38,2,6,T.COBBLE); TM.fill(64,38,2,6,T.COBBLE);

  // ── GRAVEL paths (secondary) ──
  TM.fill(16,22,32,3,T.GRAVEL); // upper west
  TM.fill(55,22,25,3,T.GRAVEL); // upper east section
  TM.fill(16,56,10,16,T.GRAVEL); // south-west connector

  // ── BUILDINGS ──
  // Helper: draws a building (wall border, floor inside, door)
  function building(x,y,w,h,doorX,doorY,label) {
    TM.fill(x,y,w,h,T.WALL);
    TM.fill(x+1,y+1,w-2,h-2,T.BUILDING_FLOOR);
    TM.set(doorX,doorY,T.DOOR);
    TM.buildingDoors.push({x:doorX, y:doorY, label, wx:x,wy:y,ww:w,wh:h});
  }

  // ── NORTH DISTRICT (between forest and main road) ──
  building(18,24,14,6, 24,29, 'Fernhaven Tavern');        // Tavern — west
  building(35,24,12,6, 40,29, "Dr. Maren's Clinic");      // Clinic
  building(56,24,12,6, 61,29, 'Tailor Vex');              // Tailor
  building(70,24,12,6, 75,29, 'General Store');           // Store

  // ── CENTRAL WEST ──
  building(18,32,10,8, 22,39, "Farmer Brix's Home");      // Farmer
  building(30,32,10,8, 34,39, "Rancher's Lodge");         // Rancher

  // ── CENTRAL EAST ──
  building(56,32,10,8, 60,39, "Rael's Cottage");          // Fisher
  building(68,32,10,8, 72,39, "Carpenter's Workshop");    // Carpenter

  // ── SOUTH DISTRICT ──
  building(18,44,10,8, 22,51, "Pip's House");             // Pip
  building(30,44,12,8, 35,51, 'Blacksmith');              // Blacksmith
  building(55,44,12,8, 60,51, "Sol's Gallery");           // Artist
  building(69,44,10,8, 73,51, "Aster's Apothecary");      // Apothecary

  // ── FAR SOUTH / OUTSKIRTS ──
  building(18,60,10,8, 22,67, "Mira's Home");             // Mira
  building(30,60,10,8, 34,67, "Elder Kael's House");      // Elder
  building(55,60,10,8, 60,67, "Wren's Bakery");           // Baker
  building(68,60,12,8, 73,67, 'Fernhaven Inn');           // Inn

  // ── CRASH SITE (north-east of town) ──
  TM.fill(85,22,12,8,T.SAND);
  TM.set(90,24,T.ROCK); TM.set(91,24,T.ROCK); TM.set(92,25,T.ROCK);
  TM.set(89,25,T.LOG);  TM.set(93,26,T.LOG);

  // ── CROPS / FARM AREA (west of town) ──
  TM.fill(4,56,12,12,T.CROP);
  TM.fill(3,55,14,1,T.FENCE); TM.fill(3,68,14,1,T.FENCE);
  TM.fill(3,55,1,13,T.FENCE); TM.fill(17,55,1,14,T.FENCE);

  // ── TREES & DECORATIVE BUSHES (around town) ──
  // Town square trees
  [[51,38],[58,38],[51,44],[58,44]].forEach(([x,y])=>TM.set(x,y,T.BUSH));
  // Road-side trees (planted, neat rows)
  for(let x=20;x<47;x+=5){ TM.set(x,29,T.TREE2); TM.set(x,44,T.TREE2); }
  for(let x=56;x<80;x+=5){ TM.set(x,29,T.TREE2); TM.set(x,44,T.TREE2); }
  // South meadow tree clusters
  [[20,70],[21,71],[38,71],[39,70],[62,70],[63,71],[78,72],[79,71]].forEach(([x,y])=>TM.set(x,y,T.TREE));
  // Decorative bushes along paths
  for(let x=18;x<47;x+=3){ if(TM.get(x,28)===T.GRASS||TM.get(x,28)===T.DARK_GRASS){ TM.set(x,28,T.BUSH); } }
  for(let x=56;x<80;x+=4){ if(TM.get(x,28)===T.GRASS){ TM.set(x,28,T.BUSH); } }
  // East side bushes
  for(let y=32;y<56;y+=4){ TM.set(84,y,T.BUSH); }

  // ── FLOWER BEDS (around buildings) ──
  [[32,29],[33,29],[62,29],[63,29],[22,43],[29,43],[57,43],[67,43]].forEach(([x,y])=>{
    if(TM.get(x,y)===T.GRASS||TM.get(x,y)===T.PATH) TM.set(x,y,T.FLOWER);
  });

  // ── ROCKS & LOGS (scattered) ──
  [[45,26],[47,27],[16,35],[15,50],[84,45],[85,50],[45,70],[75,68]].forEach(([x,y])=>TM.set(x,y,T.ROCK));

  // ── RE-STAMP ROADS (buildings may have overwritten them) ──
  TM.fill(48,22,8,52,T.PATH);
  TM.fill(16,40,72,4,T.PATH);
  TM.fill(16,30,72,3,T.PATH);
  TM.fill(16,56,72,3,T.PATH);
  TM.fill(80,22,4,52,T.PATH);
  TM.fill(48,38,16,6,T.COBBLE);
  // Restore bridges & dock
  TM.fill(86,62,7,2,T.BRIDGE);
  TM.fill(88,90,5,4,T.DOCK);
  TM.fill(26,88,4,3,T.DOCK);
  // Restore planters & signs
  TM.set(50,39,T.PLANTER); TM.set(59,39,T.PLANTER);
  TM.set(50,43,T.PLANTER); TM.set(59,43,T.PLANTER);
  TM.set(48,24,T.SIGN); TM.set(80,24,T.SIGN);

  // Build collision map
  for(let i=0;i<W*H;i++) TM.collision[i] = SOLID.has(TM.map[i]) ? 1 : 0;
  // Doors are walkable
  TM.buildingDoors.forEach(d=>{ TM.collision[d.y*W+d.x]=0; });

  console.log('[TM] Map built. Buildings:', TM.buildingDoors.length);
};
