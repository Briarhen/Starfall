// ═══════════════════════════════════════════════════════
//  INPUT
// ═══════════════════════════════════════════════════════

const INPUT = {
  keys: {},
  padIdx: null,
  prevA: false,
  prevStart: false,
};

window.addEventListener('keydown', e => {
  INPUT.keys[e.code] = true;
  // Interact
  if((e.code==='KeyE'||e.code==='Space') && !DLG.active) {
    G.tryInteract();
  }
  // Advance dialogue
  if((e.code==='KeyE'||e.code==='Space'||e.code==='Enter') && DLG.active) {
    DLG.advance();
  }
  e.preventDefault && ['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code) && e.preventDefault();
});

window.addEventListener('keyup', e => { INPUT.keys[e.code] = false; });

window.addEventListener('gamepadconnected', e => {
  INPUT.padIdx = e.gamepad.index;
  G.notify('Controller connected ✦');
});
window.addEventListener('gamepaddisconnected', () => { INPUT.padIdx = null; });

INPUT.getAxes = () => {
  let dx = 0, dy = 0, pressA = false, pressStart = false;

  // Keyboard
  if(INPUT.keys['ArrowLeft']  || INPUT.keys['KeyA']) dx = -1;
  if(INPUT.keys['ArrowRight'] || INPUT.keys['KeyD']) dx =  1;
  if(INPUT.keys['ArrowUp']    || INPUT.keys['KeyW']) dy = -1;
  if(INPUT.keys['ArrowDown']  || INPUT.keys['KeyS']) dy =  1;

  // Gamepad
  if(INPUT.padIdx !== null) {
    const gp = navigator.getGamepads()[INPUT.padIdx];
    if(gp) {
      const ax = gp.axes[0] || 0, ay = gp.axes[1] || 0;
      if(Math.abs(ax) > 0.25) dx = ax > 0 ? 1 : -1;
      if(Math.abs(ay) > 0.25) dy = ay > 0 ? 1 : -1;
      // D-pad
      if(gp.buttons[12]?.pressed) dy = -1;
      if(gp.buttons[13]?.pressed) dy =  1;
      if(gp.buttons[14]?.pressed) dx = -1;
      if(gp.buttons[15]?.pressed) dx =  1;
      pressA = !!(gp.buttons[0]?.pressed);
      pressStart = !!(gp.buttons[9]?.pressed);
    }
  }

  // Gamepad A button — interact or advance dialogue
  if(pressA && !INPUT.prevA) {
    if(DLG.active) DLG.advance();
    else G.tryInteract();
  }
  INPUT.prevA = pressA;

  return { dx, dy };
};
